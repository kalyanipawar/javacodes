package com.capgemini.service;


import com.capgemini.bean.LibBean;
import com.capgemini.exception.LibException;

public interface LibService {
	public int addUser(LibBean libbean) throws LibException;
	public boolean isValidStudent(LibBean libbean) throws LibException;
	public boolean isValidUser(LibBean en);
	
}
