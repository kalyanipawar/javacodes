package com.capgemini.service;

import java.util.Scanner;

import com.capgemini.bean.LibBean;
import com.capgemini.dao.LibDao;
import com.capgemini.dao.LibDaoImpl;
import com.capgemini.exception.LibException;

public class LibServiceImpl {

	LibDao cbd= new LibDaoImpl();
	LibBean en = new LibBean();
	Scanner sc = new Scanner(System.in);
	
	public int addUser(LibBean libbean) throws LibException {
		
		return cbd.addUser(libbean);
	}

	public boolean isValidUser(LibBean libbean) throws LibException{
		
		System.out.println("Enter your id: ");
		en.setUser_id(sc.next());
		
		if(libbean.setUser_id()==1111)
		{
			
			System.out.println("Enter book id: ");
			en.setBook_id(sc.next());
		}
		return false;
		
	}
	public boolean isValidStudent(LibBean libbean) throws LibException {
	
 	    
 	    if(libbean.getUser_name()==null){
 	    	throw new LibException("User name:", null);
 	    }
		return true;
	}

}
