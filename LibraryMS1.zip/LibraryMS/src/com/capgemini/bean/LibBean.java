package com.capgemini.bean;

public class LibBean {
	String user_id;
	String user_name;
	String book_id;
	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String string) {
		this.user_id = user_id;
	}
	public String getBook_id() {
		return book_id;
	}
	public int setUser_id() {
		// TODO Auto-generated method stub
		return 0;
	}
}
