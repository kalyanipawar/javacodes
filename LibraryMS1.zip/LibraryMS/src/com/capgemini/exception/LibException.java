package com.capgemini.exception;

import java.sql.SQLException;

public class LibException extends Exception {

	public LibException(String string, SQLException e) {
		// TODO Auto-generated constructor stub
	}

}
