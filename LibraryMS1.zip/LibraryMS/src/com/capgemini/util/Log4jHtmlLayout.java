package com.capgemini.util;

import java.util.logging.Logger;

import org.apache.log4j.PropertyConfigurator;

public class Log4jHtmlLayout {
	public Logger getlogger(){
		Logger logger = Logger.getLogger(Log4jHtmlLayout.class);
		
		PropertyConfigurator.configure("log4j.properties");
		
		return logger;
	}
	
	
	
}