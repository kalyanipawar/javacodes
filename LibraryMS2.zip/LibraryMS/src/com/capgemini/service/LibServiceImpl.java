package com.capgemini.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bean.LibBean;
import com.capgemini.dao.LibDao;
import com.capgemini.dao.LibDaoImpl;
import com.capgemini.exception.LibException;

public class LibServiceImpl {
	private static final Object[] User_id_Seq = null;
	LibDao libdao;
	
	public String addUser(LibBean libbean) throws LibException {
		
		String User_id_Seq;
		User_id_Seq= libdao.addUser(libbean);
		return User_id_Seq;
	}
	
	
		public void validateUser(LibBean bean) throws Exception
		{
			List<String> validationErrors = new ArrayList<String>();
			Scanner sc=new Scanner(System.in);
			//Validating name
			if(!(isValidUser_id==1111)) {
				System.out.println("Enter book id: ");
				bean.setBook_id(sc.next());
			}
			if(!validationErrors.isEmpty()){
				throw new LibException(validationErrors +"");
		}
			if(!(isValidUser_name(bean.getUser_name()))) {
				validationErrors.add("\n User Name Should Be In Alphabets and minimum 3 characters long ! \n");
			}
			if(!validationErrors.isEmpty())
				throw new LibException(validationErrors +"");
		}

		public boolean isValidUser_name(String User_name){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(User_name);
			return nameMatcher.matches();
		}
		  
		public boolean isValidUser_id(String User_id){
			Pattern namePattern=Pattern.compile("^[0-9]{1,4}$");
			Matcher nameMatcher=namePattern.matcher(User_id);
			return nameMatcher.matches();
		}
		  
		
		public boolean validateUser_id(String user_id) {
			
			Pattern idPattern = Pattern.compile("[0-9]{1,4}");
			Matcher idMatcher = idPattern.matcher(user_id);
			
			if(idMatcher.matches())
				return true;
			else
				return false;		
		}


		public String searchUser(int user_id) throws LibException {
				
				String data="";
				int i;
					data+= "User Id ="+User_id_Seq.length;
				
		

			return null;
		}

}
