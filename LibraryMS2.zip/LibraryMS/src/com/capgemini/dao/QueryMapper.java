package com.capgemini.dao;

public interface QueryMapper {
	public static final String RETRIVE_ALL_USERS_QUERY="SELECT user_id, user_name FROM Users";
	public static final String RETRIVE_ALL_BOOKIN_QUERY="SELECT book_id, book_name, author1, author2, publisher, yearofpublication FROM BooksInventory";
	public static final String RETRIVE_ALL_BOOKREG_QUERY="SELECT registration_id, book_id, user_id, registrationdate FROM BooksRegistration";
	public static final String RETRIVE_ALL_BOOKT_QUERY="SELECT transaction_id, registration_id, issue_date, return_date FROM BookTransaction";
	public static final String VIEW_USER_DETAILS_QUERY="SELECT user_id, user_name FROM Users WHERE  user_id=? OR user_name=?";
	public static final String INSERT_QUERY="INSERT INTO Users VALUES(User_id_Seq.NEXTVAL,?)";
	public static final String USER_ID_QUERY_SEQUENCE="SELECT User_id_sequence.CURRVAL FROM DUAL";

}
