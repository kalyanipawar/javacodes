package com.capgemini.dao;

import com.capgemini.bean.LibBean;
import com.capgemini.exception.LibException;

public interface LibDao {
	public String addUser(LibBean libbean) throws LibException;

	LibBean addUser(int user_id) throws LibException;

	LibBean searchUser(int User_Id_Seq) throws LibException;
}
