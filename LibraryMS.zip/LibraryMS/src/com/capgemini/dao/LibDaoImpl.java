package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bean.LibBean;
import com.capgemini.exception.LibException;
import com.capgemini.util.DbConnection;
import com.capgemini.util.Log4jHtmlLayout;



public class LibDaoImpl implements LibDao{
	
//Logger logger=Logger.getRootLogger();
	
	public LibDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	@SuppressWarnings("resource")
	public String addUser(LibBean libbean) throws LibException, SQLException 
	{
		Connection connection = DbConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String user_id=null;
		
		int queryResult=0;
		try
		{	
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			
			//preparedStatement.setString(1, libbean.getUser_id());
			preparedStatement.setString(1, libbean.getUser_name());
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.USER_ID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				user_id=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
			//	logger.error("Insertion failed ");
				throw new LibException("Inserting User details failed ");

			}
			else
			{
				//logger.info("User details added successfully:");
				return user_id;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			//logger.error(sqlException.getMessage());
			throw new LibException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				//logger.error(sqlException.getMessage());
				throw new LibException("Error in closing db connection");

			}
		}
		
		
	}
}
/*
	@Override
	public void searchUser(int User_Id_Seq) throws LibException {
		Connection connection = DbConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String user_id=null;
		
		int queryResult=0;
		try
		{	
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			
			//preparedStatement.setString(1, PatientMain.getPatient_id());	
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.USER_ID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				user_id=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
			//	logger.error("Insertion failed ");
				throw new LibException("Displaying User details failed ");

			}
			else
			{
				//logger.info("User details displayed successfully:");
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			//logger.error(sqlException.getMessage());
			throw new LibException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				//logger.error(sqlException.getMessage());
				throw new LibException("Error in closing db connection");

			}
		}
		
		
	}
}

*/