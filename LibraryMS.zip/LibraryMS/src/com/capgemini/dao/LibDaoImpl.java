package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import com.capgemini.bean.LibBean;
import com.capgemini.exception.LibException;



public class LibDaoImpl implements LibDao{
	
private static Logger log = Logger.getLogger(Log4jHTMLLayout.class);
	
	private Connection dbConnection;

	{
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	

   
   
	
	

	//implemented Methods
	
	@Override
	public int addStudent(LibBean libbean) throws LibException {
		
		String insertQuery = "insert into User values(?,?)";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			
			
			insertStatement.setString(2, libbean.getUser_name());
			
			
			
			int rows = insertStatement.executeUpdate();
			
			if(rows>0){
				System.out.println("New Entry Added..");
				log.info("New Entry is Added");
				return 1;
			}
			else 
				return 0;
				
		} catch (SQLException e) {
			
			e.printStackTrace();
			log.error(e.getMessage());
			return 0;
		}
		
		
	}

	
	
	




	@Override
	public LibBean addStudent(int user_id) throws LibException {
		
		String selectQuery = "select * from employee where employeeNo = ?";
		
		try{
		
		PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
		
		selectStatement.setInt(1, user_id);
		
		ResultSet result = selectStatement.executeQuery();
		
		while (result.next()) {
			
			int employeeNo = result.getInt(1);
			
			String employeeName = result.getString(2);
			
			
			Employee employee = new Employee();
			employee.setEmployeeNo(employeeNo);
			employee.setEmployeeName(employeeName);
		
			return employee;
			
		}
		
		} catch(SQLException e){
			
			e.printStackTrace();
			
			throw new EmployeeException("Employee not found",e);
		}
		
		return null;
	}
	
	
	
}


