package com.capgemini.util;

public class Log4jHtmlLayout {

}
