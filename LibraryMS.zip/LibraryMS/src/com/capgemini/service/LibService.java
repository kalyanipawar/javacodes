package com.capgemini.service;


import com.capgemini.bean.LibBean;
import com.capgemini.exception.LibException;

public interface LibService {
	public int addStudent(LibBean libbean) throws LibException;
	public boolean isValidStudent(LibBean libbean) throws LibException;
	
}
