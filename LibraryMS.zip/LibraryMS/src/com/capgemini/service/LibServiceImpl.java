package com.capgemini.service;

import com.capgemini.bean.LibBean;
import com.capgemini.dao.LibDao;
import com.capgemini.dao.LibDaoImpl;
import com.capgemini.exception.LibException;

public class LibServiceImpl {

	LibDao cbd= new LibDaoImpl();
	
	public int addStudent(LibBean libbean) throws LibException {
		
		return cbd.addStudent(libbean);
	}

	public boolean isValidStudent(LibBean libbean) throws LibException {
	
 	    
 	    if(libbean.getUser_name()==null){
 	    	throw new LibException();
 	    }
		return true;
	}

}
