package com.capgemini.librarian.dao;
import com.capgemini.librarian_dto. Addview_book;
import java.sql.SQLException;
import com.capgemini.exception.FilenotfoundException;
import com.capgemini.librarian_dto.Del_book;
import com.capgemini.librarian_dto.Reg_user;


public interface Libra_dao {
	
	public int Addview (Addview_book ad) throws FilenotfoundException,SQLException,ClassNotFoundException;
	public void Delete(Del_book db) throws FilenotfoundException,SQLException,ClassNotFoundException;
	public void Register(Reg_user ru) throws FilenotfoundException,SQLException,ClassNotFoundException;
	
	

}
