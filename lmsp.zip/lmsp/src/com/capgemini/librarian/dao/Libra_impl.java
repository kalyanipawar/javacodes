package com.capgemini.librarian.dao;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.capgemini.dao.DButil;
import com.capgemini.exception.FilenotfoundException;
import com.capgemini.librarian_dto.Addview_book;
import com.capgemini.librarian_dto.Del_book;
import com.capgemini.librarian_dto.Reg_user;


public class Libra_impl implements Libra_dao {



	public int Addview (Addview_book ad) throws FilenotfoundException,SQLException,ClassNotFoundException
	{
		Connection con1;
		con1= Libra_db.getConnection();
		String sql= "insert into books_inventory values(?,?,?,?)";
		try {
			
		PreparedStatement pst = con1.prepareStatement(sql);
			pst.setInt(1, ad.getBook_id());
			pst.setString(1, ad.getBook_name());
			pst.setString(2, ad.getAuthor1());
			pst.setString(3, ad.getAuthor2());
			pst.setString(4, ad.getPublication());
			pst.setString(5, ad.getYearofpublication());
			pst.executeUpdate();
		}
		catch (SQLException e) {
			throw new FilenotfoundException("Problem in inserting the details "
							+e.getMessage());
		}
		
		
		return ad.getBook_id();
	}
	
	public void Delete(Del_book db) throws FilenotfoundException,SQLException,ClassNotFoundException
	{
		Connection con1;
		con1= Libra_db.getConnection();
		String deletebook = "delete from books_inventory where book_id = ?";
		try {
			
			PreparedStatement pst = con1.prepareStatement(deletebook);
			pst.setInt(1, db.getBook_id());
			
			pst.executeQuery();
		
		}
		catch (SQLException e) {
			throw new FilenotfoundException("Problem in deleting details "
							+e.getMessage());
		}
		
	}
	
	
public void Register(Reg_user ru) throws FilenotfoundException,SQLException,ClassNotFoundException

{
	Connection con1;
	con1= Libra_db.getConnection();
	String registration ="insert into re_user values(?,?,?,?)";
	try {
		PreparedStatement pst = con1.prepareStatement(registration);
		pst.setString(1, ru.getUser_id());
		pst.setString(2, ru.getUser_name());
		pst.setString(3, ru.getPassword());
		pst.setString(4, ru.getEmail_id());
		pst.executeUpdate(registration);
	}
	catch (SQLException e) {
		throw new FilenotfoundException("Problem in deleting details "
						+e.getMessage());
	}
	
	
	}


}



























































