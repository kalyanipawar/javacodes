package com.capgemini.servicelayer;

import java.sql.SQLException;


import com.capgemini.dto.Lib_dto;
import com.capgemini.exception.FilenotfoundException;

public interface Lib_service {
 public int Insertissuedetails(Lib_dto dto) throws FilenotfoundException,SQLException,ClassNotFoundException;
 public void returnbook(Lib_dto del) throws FilenotfoundException,SQLException,ClassNotFoundException;
	    

}
