package com.capgemini.servicelayer;

import com.capgemini.dto.Lib_dto;


import com.capgemini.exception.FilenotfoundException;
import com.capgemini.dao.Lib_daoimpl;
import java.sql.SQLException;

public class Lib_serviceimpl implements Lib_service {

	
	private Lib_daoimpl dao= new Lib_daoimpl();
	public int Insertissuedetails(Lib_dto dto) throws FilenotfoundException,SQLException,ClassNotFoundException
	{
		
		int g = dao.Insertissuedetails(dto);
		return g;
	
		
	}
    public void returnbook(Lib_dto del) throws FilenotfoundException,SQLException,ClassNotFoundException
    {
    	
   dao.returnbook(del);
    }
}
