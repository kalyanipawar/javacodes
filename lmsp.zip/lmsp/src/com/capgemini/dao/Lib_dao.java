package com.capgemini.dao;


import java.sql.SQLException;

import com.capgemini.dto.Lib_dto;
import com.capgemini.exception.FilenotfoundException;

public interface Lib_dao {
	
	public int Insertissuedetails(Lib_dto dto) throws FilenotfoundException, ClassNotFoundException, SQLException;
    public void returnbook(Lib_dto del)  throws FilenotfoundException, ClassNotFoundException, SQLException;
}