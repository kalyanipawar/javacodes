package com.capgemini.dao;
import com.capgemini.dto.Lib_dto;




import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.dto.Lib_dto;
import com.capgemini.exception.FilenotfoundException;

public class Lib_daoimpl implements Lib_dao{
	
	

	public int Insertissuedetails(Lib_dto dto) throws FilenotfoundException, ClassNotFoundException, SQLException
		
		{
		 Connection con;
		con= DButil.getConnection();
		PreparedStatement pst;		
		PreparedStatement pst1;	
		ResultSet resultSet = null;
		
		int regid=0;
		
		int queryResult=0;
		
		String sql = "insert into books_registration values(?,?)";
		try {
	        pst = con.prepareStatement(sql);
	        pst.setInt(1, dto.getBook_id());
	        pst.setString(2, dto.getStudent_id());
			
	    
			queryResult=pst.executeUpdate();

			pst1= con.prepareStatement("SELECT regid.NEXTVAL FROM DUAL");
			
			resultSet=pst1.executeQuery();

			if(resultSet.next())
			{
				regid=resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				throw new  FilenotfoundException("Inserting details failed ");

			}
			else
			{
				return regid;
			}
			
			
		} 
		
		catch (SQLException e) {
			throw new FilenotfoundException("Problem in inserting the details "
							+e.getMessage());
		}
		
		
	}
	@Override
	public void returnbook(Lib_dto del) throws FilenotfoundException, ClassNotFoundException, SQLException {
		 Connection con;
			con= DButil.getConnection();
		PreparedStatement ps=null;
		String bookreturn= "delete from books_registration where book_id=?";
		try{
			ps= con.prepareStatement(bookreturn);
			ps.setInt(1, del.getBook_id());
			ps.executeUpdate();
		}
		catch (SQLException e) {
			throw new FilenotfoundException("Problem in deleting details "
							+e.getMessage());
	}


	}
}
