package com.capgemini.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.dao.Lib_dao;
import com.capgemini.dao.Lib_daoimpl;
import com.capgemini.dto.Lib_dto;
import com.capgemini.exception.FilenotfoundException;
import com.capgemini.librarian.dao.Libra_impl;
import com.capgemini.librarian_dto.Addview_book;
import com.capgemini.librarian_dto.Del_book;
import com.capgemini.librarian_dto.Reg_user;
import java.sql.SQLException;

public class LibTest {
	static Lib_daoimpl li;
	static Lib_dto ab;
	static Del_book db;
	static Reg_user ru;
	static Addview_book av;
	static Libra_impl lim;
	

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		Addview_book hu = new Addview_book(); 
		Del_book db1 = new Del_book();
		li= new Lib_daoimpl();
		ab = new Lib_dto();
		db = new Del_book();
		ru = new Reg_user();
		av = new Addview_book();
		lim = new Libra_impl();
	}

	@Test
	public void testInsertIssueDetails() throws FilenotfoundException,ClassNotFoundException,SQLException{

		assertNotNull(li.Insertissuedetails(ab));

	}
	
	@Ignore
	@Test
	
	public void testReturnBook() throws FilenotfoundException {
		// increment the number next time you test for positive test case
		assertEquals(li.returnbook(ab));
	}
	
	
	@Test
	public void testAddView_book() throws FilenotfoundException {
		Addview_book hu = new Addview_book(); 
		av.setBook_id(1321);
		av.setBook_name("Java");
		av.setAuthor1("dan");
		av.setAuthor2("brown");
		av.setPublication("tmh");
		av.setYearofpublication("2567");
		//ab.setAddress("whitefield");
		//ab.setDonationAmount(5000);
		

	}
	
	@Ignore
	@Test
	public void testDel_book() throws FilenotfoundException {

		Del_book db1 = new Del_book();
		db.setBook_id(1222);
		db.setBook_name("C++");
		assertEquals(db1.Del_book(db));

	}
	
	@Test
	public void testRegister() throws FilenotfoundException {

		ru.setUser_id("1222");
		ru.setUser_name("Library");
		ru.setPassword("CapGe&18");
		ru.setEmail_id("oman.g803@rediff.com");
		//assertEquals(ru.addRegister(ru));

	}
	
}
